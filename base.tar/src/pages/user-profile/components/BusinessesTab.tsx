import { BadgeCheck, BookOpen, Calendar, Crown, Edit3, Eye, Lock, MapPin, Plus, Search, Star, Store, TicketPercent, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import Pagination from "@/components/Pagination";
import { TabsContent } from "@/components/ui/tabs";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { buildBusinessUrl, getCategoryId, getCountryName } from "@/services/businesses";
import { preloadBusinessPageAssets } from "@/pages/BusinessPagePrefetch";
import { getCityDisplayName } from "@/lib/locationDisplay";
import { DEFAULT_BUSINESS_LOGO } from "@/lib/images";
import { getBusinessProfileCompletionData, getBusinessProfileScore } from "@/lib/profileCompleteness";
import type { BusinessFrontend } from "@/types/database";

type BusinessesTabProps = {
  loadingMyBusinesses: boolean;
  myBusinesses: BusinessFrontend[];
  paginatedMyBusinesses: BusinessFrontend[];
  filteredMyBusinesses: BusinessFrontend[];
  myBusinessesTotalPages: number;
  safeMyBusinessesPage: number;
  getMyVerificationStatusByBusiness: (businessId: string) => string | null;
  getCategoryLabel: (category: string) => string;
  myBusinessesSearch: string;
  onSearchChange: (value: string) => void;
  onPageChange: (page: number) => void;
  onOpenMenuModal: (business: BusinessFrontend) => void;
  onOpenServicesModal: (business: BusinessFrontend) => void;
  onOpenEventsModal: (business: BusinessFrontend) => void;
  onOpenCouponModal: (business: BusinessFrontend) => void;
  onOpenVerificationModal: (business: BusinessFrontend) => void;
  onDeleteMyBusiness: (business: BusinessFrontend) => void;
};

function BusinessProfileScoreBadge({ business }: { business: BusinessFrontend }) {
  const profileScore = getBusinessProfileScore(getBusinessProfileCompletionData(business));

  if (profileScore === 100) {
    return (
      <Badge className="inline-flex items-center gap-1 border-amber-300 bg-amber-100 text-amber-900" title="Perfil completo">
        <Crown className="h-3.5 w-3.5 fill-amber-500 text-amber-600" />
        100% completo
      </Badge>
    );
  }

  return (
    <Badge variant="outline" className="border-amber-300/70 text-amber-800" title="Completude do perfil">
      Perfil {profileScore}% completo
    </Badge>
  );
}

function hasNamedItems(items: Array<{ name?: string }> | undefined): boolean {
  return !!items?.some((item) => String(item.name || "").trim());
}

function BusinessContentButton({
  business,
  onOpenMenu,
  onOpenServices,
}: {
  business: BusinessFrontend;
  onOpenMenu: (business: BusinessFrontend) => void;
  onOpenServices: (business: BusinessFrontend) => void;
}) {
  const isFoodBusiness = getCategoryId(business.category) === "food";
  const hasContent = isFoodBusiness
    ? hasNamedItems(business.menu) || Boolean(business.menuPdfUrl?.trim())
    : hasNamedItems(business.serviceItems) || business.services.some((service) => service.trim());
  const label = isFoodBusiness ? "Card\u00e1pio" : "Servi\u00e7os";
  const explanation = isFoodBusiness
    ? "Adicione pratos, produtos, pre\u00e7os e, se quiser, envie tamb\u00e9m um PDF do seu card\u00e1pio. Essas informa\u00e7\u00f5es aparecer\u00e3o na p\u00e1gina p\u00fablica do neg\u00f3cio para que os clientes conhe\u00e7am suas op\u00e7\u00f5es antes de entrar em contato, decidam com mais seguran\u00e7a e encontrem rapidamente o que procuram. Um card\u00e1pio completo tamb\u00e9m deixa seu perfil mais profissional."
    : "Adicione os servi\u00e7os que voc\u00ea oferece e, quando poss\u00edvel, inclua detalhes, pre\u00e7os e condi\u00e7\u00f5es. Essa se\u00e7\u00e3o aparecer\u00e1 na p\u00e1gina p\u00fablica do neg\u00f3cio e ajuda os clientes a entender rapidamente se voc\u00ea atende \u00e0s necessidades deles, comparar op\u00e7\u00f5es e entrar em contato com mais confian\u00e7a. Manter os servi\u00e7os atualizados deixa seu perfil mais completo e profissional.";
  const onClick = () => (isFoodBusiness ? onOpenMenu(business) : onOpenServices(business));
  const button = (
    <Button
      size="sm"
      variant="outline"
      onClick={onClick}
      className={hasContent ? "w-full sm:w-auto" : "w-full animate-pulse border-amber-400 bg-amber-50 text-amber-900 ring-2 ring-amber-300/70 hover:bg-amber-100 sm:w-auto"}
    >
      <BookOpen className="mr-1.5 h-3.5 w-3.5" />
      {label}
    </Button>
  );

  if (hasContent) return button;

  return (
    <TooltipProvider delayDuration={150}>
      <Tooltip>
        <TooltipTrigger asChild>{button}</TooltipTrigger>
        <TooltipContent side="top" className="max-w-sm whitespace-normal text-sm leading-relaxed sm:max-w-md">
          {explanation}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
export default function BusinessesTab({
  loadingMyBusinesses,
  myBusinesses,
  paginatedMyBusinesses,
  filteredMyBusinesses,
  myBusinessesTotalPages,
  safeMyBusinessesPage,
  getMyVerificationStatusByBusiness,
  getCategoryLabel,
  myBusinessesSearch,
  onSearchChange,
  onPageChange,
  onOpenMenuModal,
  onOpenServicesModal,
  onOpenEventsModal,
  onOpenCouponModal,
  onOpenVerificationModal,
  onDeleteMyBusiness,
}: BusinessesTabProps) {
  return (
    <TabsContent value="negocios" className="mt-0">
      <div className="mb-8 rounded-2xl border border-border/70 bg-card/70 p-4 shadow-sm sm:p-5">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-2xl font-bold text-foreground">Meus negócios</h2>
            <p className="mt-1 text-sm text-muted-foreground">Gerencie e encontre rapidamente seus negócios cadastrados.</p>
          </div>
          <Link to="/negocio/wizard" className="w-full sm:w-auto">
            <Button size="sm" className="w-full sm:w-auto">
              <Plus className="mr-1 h-3.5 w-3.5" />
              Adicionar novo negócio
            </Button>
          </Link>
        </div>

        <div className="relative mt-5 w-full max-w-xl">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            id="my-businesses-search"
            type="search"
            value={myBusinessesSearch}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Buscar por nome, cidade ou país"
            aria-label="Buscar por nome, cidade ou país"
            className="h-10 pl-9"
          />
        </div>
      </div>
      {loadingMyBusinesses && myBusinesses.length === 0 ? (
        <Card className="border-border p-8 text-center">
          <Store className="mx-auto mb-3 h-12 w-12 animate-pulse text-muted-foreground/30" />
          <p className="mb-1 text-muted-foreground">Carregando seus negócios...</p>
        </Card>
      ) : myBusinesses.length === 0 ? (
        <Card className="border-border p-8 text-center">
          <Store className="mx-auto mb-3 h-12 w-12 text-muted-foreground/30" />
          <p className="mb-4 text-muted-foreground">Você ainda não cadastrou nenhum negócio.</p>
          <Link to="/negocio/wizard">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Cadastrar negócio
            </Button>
          </Link>
        </Card>
      ) : filteredMyBusinesses.length === 0 ? (
        <Card className="border-border p-8 text-center">
          <Store className="mx-auto mb-3 h-10 w-10 text-muted-foreground/30" />
          <p className="text-muted-foreground">Nenhum negócio encontrado com esse filtro.</p>
        </Card>
      ) : (
        <div id="meus-negocios-lista" className="space-y-4">
          {paginatedMyBusinesses.map((biz) => (
            <Card key={biz.id} className="min-h-[160px] border-border p-4">
              <div className="flex items-start gap-4">
                <div className="h-14 w-14 flex-shrink-0 overflow-hidden rounded-lg bg-secondary">
                  <img
                    src={biz.logoUrl || DEFAULT_BUSINESS_LOGO}
                    alt={biz.name}
                    className="h-full w-full object-cover"
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <Link
                      to={buildBusinessUrl(biz)}
                      state={{ preloadedBusiness: biz }}
                      onMouseEnter={() => preloadBusinessPageAssets(biz)}
                      onFocus={() => preloadBusinessPageAssets(biz)}
                      onPointerDown={() => preloadBusinessPageAssets(biz)}
                      className="font-bold text-foreground transition-colors hover:text-primary"
                    >
                      {biz.name}
                    </Link>
                    <BusinessProfileScoreBadge business={biz} />
                    {biz.moderationStatus === "pending" ? (
                      <Badge variant="outline" className="border-amber-300 bg-amber-50 text-amber-800">
                        Em analise
                      </Badge>
                    ) : null}
                    {biz.moderationStatus === "rejected" ? (
                      <Badge variant="outline" className="border-destructive/30 text-destructive">
                        Rejeitado
                      </Badge>
                    ) : null}
                    {(() => {
                      const status = getMyVerificationStatusByBusiness(biz.id);
                      if (!status) return null;
                      if (status === "pending") return <Badge variant="outline">{"Verifica\u00e7\u00e3o pendente"}</Badge>;
                      if (status === "approved" && biz.ownerVerified) {
                        return (
                          <Badge className="inline-flex items-center gap-1.5 bg-emerald-600 text-white">
                            <Lock className="h-3 w-3" />
                            Verificado
                          </Badge>
                        );
                      }
                      if (status === "approved" && !biz.ownerVerified) {
                        return <Badge variant="outline">{"Verifica\u00e7\u00e3o expirada"}</Badge>;
                      }
                      return (
                        <Badge variant="outline" className="border-destructive/30 text-destructive">
                          {"Verifica\u00e7\u00e3o rejeitada"}
                        </Badge>
                      );
                    })()}
                  </div>
                </div>
                <Badge variant="secondary" className="flex-shrink-0">
                  {getCategoryLabel(biz.category).split(" (")[0]}
                </Badge>
              </div>

              <div className="mt-2 flex items-center justify-between gap-3 text-sm text-muted-foreground">
                <span className="flex min-w-0 items-center gap-1 leading-tight">
                  <MapPin className="h-3 w-3 shrink-0" />
                  <span className="truncate">
                    {getCityDisplayName(biz.address.cityDisplayName || biz.address.city, biz.address.countryCode || biz.address.country)}, {getCountryName(biz.address.countryCode || biz.address.country)}
                  </span>
                </span>
                <span className="flex shrink-0 items-center gap-1 whitespace-nowrap leading-tight">
                  <Star className="h-3 w-3 shrink-0 text-amber-500" />
                  <span>
                    {biz.averageRating.toFixed(1)} ({biz.reviews.length} {biz.reviews.length === 1 ? "avaliação" : "avaliações"})
                  </span>
                </span>
              </div>

              <div className="mt-3 border-t border-border/60 pt-3">
                <div className="grid items-stretch gap-2 sm:flex sm:flex-wrap sm:items-center grid-cols-2">
                  <Link to={`/negocio/wizard?editBusinessId=${biz.id}`}>
                    <Button size="sm" variant="outline" className="w-full sm:w-auto">
                      <Edit3 className="mr-1.5 h-3.5 w-3.5" />
                      Editar
                    </Button>
                  </Link>

                  <BusinessContentButton
                    business={biz}
                    onOpenMenu={onOpenMenuModal}
                    onOpenServices={onOpenServicesModal}
                  />
                  <Button size="sm" variant="outline" onClick={() => onOpenEventsModal(biz)} className="w-full sm:w-auto">
                    <Calendar className="mr-1.5 h-3.5 w-3.5" />
                    Eventos
                  </Button>

                  <Button size="sm" variant="outline" onClick={() => onOpenCouponModal(biz)} className="w-full sm:w-auto">
                    <TicketPercent className="mr-1.5 h-3.5 w-3.5" />
                    {"Promo\u00e7\u00f5es"}
                  </Button>

                  {!biz.ownerVerified ? (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onOpenVerificationModal(biz)}
                      disabled={getMyVerificationStatusByBusiness(biz.id) === "pending"}
                      className="w-full sm:w-auto"
                      title={
                        getMyVerificationStatusByBusiness(biz.id) === "pending"
                          ? "Já existe uma solicitação pendente"
                          : "Solicitar verifica\u00e7\u00e3o"
                      }
                    >
                      <BadgeCheck className="mr-1.5 h-3.5 w-3.5" />
                      {"Solicitar verifica\u00e7\u00e3o"}
                    </Button>
                  ) : null}

                  <div className="col-span-2 flex items-center justify-end gap-2 pt-1 sm:col-auto sm:ml-auto sm:pt-0">
                    <Button
                      size="sm"
                      variant="outline"
                      asChild
                      aria-label={`Ver ${biz.name}`}
                    title={biz.moderationStatus === "approved" ? "Ver negócio" : "Pré-visualizar negócio em análise"}
                    >
                    <Link
                      to={biz.moderationStatus === "approved" ? buildBusinessUrl(biz) : `/preview/negocio/${biz.id}`}
                      state={{ preloadedBusiness: biz }}
                      onMouseEnter={() => preloadBusinessPageAssets(biz)}
                      onFocus={() => preloadBusinessPageAssets(biz)}
                      onPointerDown={() => preloadBusinessPageAssets(biz)}
                      target={biz.moderationStatus === "approved" ? "_blank" : undefined}
                      rel={biz.moderationStatus === "approved" ? "noreferrer" : undefined}
                    >
                        <Eye className="h-3.5 w-3.5" />
                      </Link>
                    </Button>

                    <Button
                      size="sm"
                      variant="outline"
                      className="border-destructive/30 text-destructive hover:bg-destructive/10"
                      onClick={() => onDeleteMyBusiness(biz)}
                      aria-label={`Excluir ${biz.name}`}
                      title="Excluir negócio"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          ))}

          {myBusinessesTotalPages > 1 ? (
            <Pagination
              currentPage={safeMyBusinessesPage}
              totalPages={myBusinessesTotalPages}
              onPageChange={onPageChange}
              className="pt-2"
            />
          ) : null}
        </div>
      )}
    </TabsContent>
  );
}
