const COUNTRY_TO_CURRENCY: Record<string, string> = {
  ad: "EUR", ae: "AED", af: "AFN", ag: "XCD", ai: "XCD", al: "ALL", am: "AMD", ao: "AOA",
  ar: "ARS", as: "USD", at: "EUR", au: "AUD", aw: "AWG", ax: "EUR", az: "AZN",
  ba: "BAM", bb: "BBD", bd: "BDT", be: "EUR", bf: "XOF", bg: "BGN", bh: "BHD", bi: "BIF",
  bj: "XOF", bl: "EUR", bm: "BMD", bn: "BND", bo: "BOB", bq: "USD", br: "BRL", bs: "BSD",
  bt: "BTN", bw: "BWP", by: "BYN", bz: "BZD",
  ca: "CAD", cc: "AUD", cd: "CDF", cf: "XAF", cg: "XAF", ch: "CHF", ci: "XOF", ck: "NZD",
  cl: "CLP", cm: "XAF", cn: "CNY", co: "COP", cr: "CRC", cu: "CUP", cv: "CVE", cw: "ANG",
  cx: "AUD", cy: "EUR", cz: "CZK",
  de: "EUR", dj: "DJF", dk: "DKK", dm: "XCD", do: "DOP", dz: "DZD",
  ec: "USD", ee: "EUR", eg: "EGP", eh: "MAD", er: "ERN", es: "EUR", et: "ETB",
  fi: "EUR", fj: "FJD", fk: "FKP", fm: "USD", fo: "DKK", fr: "EUR",
  ga: "XAF", gb: "GBP", gd: "XCD", ge: "GEL", gf: "EUR", gg: "GBP", gh: "GHS", gi: "GIP",
  gl: "DKK", gm: "GMD", gn: "GNF", gp: "EUR", gq: "XAF", gr: "EUR", gt: "GTQ", gu: "USD",
  gw: "XOF", gy: "GYD",
  hk: "HKD", hn: "HNL", hr: "EUR", ht: "HTG", hu: "HUF",
  id: "IDR", ie: "EUR", il: "ILS", im: "GBP", in: "INR", io: "USD", iq: "IQD", ir: "IRR",
  is: "ISK", it: "EUR",
  je: "GBP", jm: "JMD", jo: "JOD", jp: "JPY",
  ke: "KES", kg: "KGS", kh: "KHR", ki: "AUD", km: "KMF", kn: "XCD", kp: "KPW", kr: "KRW",
  kw: "KWD", ky: "KYD", kz: "KZT",
  la: "LAK", lb: "LBP", lc: "XCD", li: "CHF", lk: "LKR", lr: "LRD", ls: "LSL", lt: "EUR",
  lu: "EUR", lv: "EUR", ly: "LYD",
  ma: "MAD", mc: "EUR", md: "MDL", me: "EUR", mf: "EUR", mg: "MGA", mh: "USD", mk: "MKD",
  ml: "XOF", mm: "MMK", mn: "MNT", mo: "MOP", mp: "USD", mq: "EUR", mr: "MRU", ms: "XCD",
  mt: "EUR", mu: "MUR", mv: "MVR", mw: "MWK", mx: "MXN", my: "MYR", mz: "MZN",
  na: "NAD", nc: "XPF", ne: "XOF", nf: "AUD", ng: "NGN", ni: "NIO", nl: "EUR", no: "NOK",
  np: "NPR", nr: "AUD", nu: "NZD", nz: "NZD",
  om: "OMR",
  pa: "PAB", pe: "PEN", pf: "XPF", pg: "PGK", ph: "PHP", pk: "PKR", pl: "PLN", pm: "EUR",
  pn: "NZD", pr: "USD", ps: "ILS", pt: "EUR", pw: "USD", py: "PYG",
  qa: "QAR",
  re: "EUR", ro: "RON", rs: "RSD", ru: "RUB", rw: "RWF",
  sa: "SAR", sb: "SBD", sc: "SCR", sd: "SDG", se: "SEK", sg: "SGD", sh: "SHP", si: "EUR",
  sj: "NOK", sk: "EUR", sl: "SLE", sm: "EUR", sn: "XOF", so: "SOS", sr: "SRD", ss: "SSP",
  st: "STN", sv: "USD", sx: "ANG", sy: "SYP", sz: "SZL",
  tc: "USD", td: "XAF", tg: "XOF", th: "THB", tj: "TJS", tk: "NZD", tl: "USD", tm: "TMT",
  tn: "TND", to: "TOP", tr: "TRY", tt: "TTD", tv: "AUD", tw: "TWD", tz: "TZS",
  ua: "UAH", ug: "UGX", us: "USD", uy: "UYU", uz: "UZS",
  va: "EUR", vc: "XCD", ve: "VES", vg: "USD", vi: "USD", vn: "VND", vu: "VUV",
  wf: "XPF", ws: "WST",
  ye: "YER", yt: "EUR",
  za: "ZAR", zm: "ZMW", zw: "USD",
};

const CURRENCY_SYMBOL_HINT: Record<string, string> = {
  AED: "د.إ", ARS: "$", AUD: "$", BRL: "R$", CAD: "$", CHF: "Fr", CNY: "¥", CZK: "Kč",
  DKK: "kr", EUR: "€", GBP: "£", HKD: "$", HUF: "Ft", IDR: "Rp", ILS: "₪", INR: "₹",
  JPY: "¥", KRW: "₩", MXN: "$", NOK: "kr", NZD: "$", PLN: "zł", QAR: "﷼", RUB: "₽",
  SAR: "﷼", SEK: "kr", SGD: "$", THB: "฿", TRY: "₺", TWD: "$", USD: "$", ZAR: "R",
};

export function getCurrencyCodeForCountry(countryCode: string): string {
  const cc = (countryCode || "").trim().toLowerCase();
  return COUNTRY_TO_CURRENCY[cc] || "USD";
}

export function getCurrencyPrefixForCountry(countryCode: string): string {
  const currency = getCurrencyCodeForCountry(countryCode);
  const symbol = CURRENCY_SYMBOL_HINT[currency];
  if (!symbol) return `${currency} `;
  return `${currency}${symbol} `;
}

